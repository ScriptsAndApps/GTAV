scripthookv for gta online version 1.66

dsound.dll asi loader (delete dinput8.dll if installed)



optionally use openiv.asi from openiv to use "mods" folder


all files must be in game directory



enjoy :)